package com.example.NetDisk.fileupload;

import com.example.NetDisk.users.Users;
import com.example.NetDisk.utils.DruidUtils;
import com.example.NetDisk.utils.UploadUtils;
import org.apache.commons.dbutils.QueryRunner;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import java.io.IOException;
import java.sql.Date;
import java.util.HashMap;

/**
 * @ClassName: ${NAME}
 * @Description: TODO
 * @author: LebronFans
 * @date: 2020/12/9  20:14
 */
@WebServlet("/upload")
public class UploadServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HashMap<String, Object> map = new HashMap<>(16);
        Users users = (Users) request.getSession().getAttribute("users");
        String username = users.getUsername();
        try {
            DataSource dataSource = DruidUtils.getDataSource();
            QueryRunner queryRunner = new QueryRunner(dataSource);
            UploadUtils.upload(request,map);
            String filename = (String) map.get("file");
            String filepath = (String) map.get("filepath");
//            文件为空，上传文件失败
            if (filename == null || filepath == null) {
                request.getRequestDispatcher("/failUpload").forward(request,response);
            }
//            将上传的数据导入数据库
            queryRunner.update("insert into filelist values(null,?,now(),?,?)",username,filename,filepath);
        } catch (Exception e) {
            e.printStackTrace();
        }
        response.getWriter().println("上传成功，两秒钟后跳转至主页面");
        response.setHeader("Refresh","2;/netdisk/main.html");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
