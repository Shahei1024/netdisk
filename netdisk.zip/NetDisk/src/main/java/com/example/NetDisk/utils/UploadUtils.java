package com.example.NetDisk.utils;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.UnsupportedEncodingException;
import java.sql.Date;
import java.util.*;

/**
 * @ClassName: UploadUtils
 * @Description: TODO
 * @author: LebronFans
 * @date: 2020/12/2  17:18
 */
public class UploadUtils {
    public static void upload(HttpServletRequest request, HashMap<String, Object> map) throws Exception {
        DiskFileItemFactory factory = new DiskFileItemFactory();
//        得到Context域
        ServletContext servletContext = request.getServletContext();
//        在Context域中得到属性，设置仓库
        File repository = (File) servletContext.getAttribute("javax.servlet.context.tempdir");
        factory.setRepository(repository);
//        得到一个文件处理器
        ServletFileUpload upload = new ServletFileUpload(factory);
//        我们知道由于表单元素设置了enctype，所以会导致post请求体中的数据结构乱码，所以要用此方法对请求体中的数据进行解析，得到一个数据集合
        List<FileItem> items = upload.parseRequest(request);
        for (FileItem item : items) {
            if (item.getSize() == 0) {
                return;
            }
            if (item.isFormField()) {
//                处理表单中出现的成员变量，虽然这里没有
                processingFormField(item,map);
            }
            else {
                processingUpLoadFile(item,map,request);
            }
        }
    }

    private static void processingUpLoadFile(FileItem item, HashMap<String, Object> map, HttpServletRequest request) throws Exception {
//        得到文件的文件名
        String name = item.getName();
        String uuid = UUID.randomUUID().toString();
//        将uuid这个随机字符串与文件名结合，存放到本地中
        String fileName = uuid + name;
//        当用户上传的文件数目过多时，我们可以对文件采取多级目录索引的方式存储
//        取文件名的hashcode值并转为16进制，每一个进制代表16个目录，一共八级目录，这样就能达到均匀散列的目的，避免一个目录中文件过多
        int hashCode = fileName.hashCode();
        String hexString = Integer.toHexString(hashCode);
        String filePath = "upload";
//        得到16进制数组
        char[] chars = hexString.toCharArray();
        for (int i = 0; i < chars.length; i++) {
//            目录分级
            filePath = filePath + "/" + chars[i];
        }
        filePath = filePath + "/" + fileName;
//        设置本地存储路径
        filePath = request.getServletContext().getRealPath("") + filePath;
//        根据路径创建一个文件
        File file = new File(filePath);
//        如果父目录不存在，创建目录
        if (!file.getParentFile().exists()) {
            file.getParentFile().mkdirs();
        }
//        把请求体中文件的数据写入到本地新建的文件中
        item.write(file);
        map.put("file",name);
        map.put("filepath",filePath);
    }

    private static void processingFormField(FileItem item, HashMap<String, Object> map) throws UnsupportedEncodingException {
//        得到name属性值
        String fieldName = item.getFieldName();
        String value = item.getString("utf-8");
        if (fieldName == null || fieldName.isEmpty()) {
            return;
        }
        map.put(fieldName,value);
    }
}
