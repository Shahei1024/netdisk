package com.example.NetDisk.fileupload;

import com.example.NetDisk.filelist.FileList;
import com.example.NetDisk.utils.DruidUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.SQLException;

/**
 * @ClassName: ${NAME}
 * @Description: TODO
 * @author: LebronFans
 * @date: 2020/12/9  21:13
 */
@WebServlet("/download")
public class DownloadServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("id");
        System.out.println(id);
        DataSource dataSource = DruidUtils.getDataSource();
        QueryRunner queryRunner = new QueryRunner(dataSource);
        FileInputStream inputStream = null;
        ServletOutputStream outputStream = null;
        try {
            FileList fileList = queryRunner.query("select * from filelist where id = ?",
                    new BeanHandler<>(FileList.class), id);
            String filepath = fileList.getFilepath();
            System.out.println(filepath);
            inputStream = new FileInputStream(filepath);
            outputStream = response.getOutputStream();
            byte[] bytes = new byte[1024];
            int length;
            //        设置响应头，附件名称
            response.setHeader("content-disposition", "attachment;filename="+fileList.getFilename());
            while ((length = inputStream.read(bytes)) != -1) {
                outputStream.write(bytes,0,length);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } finally {
            assert inputStream != null;
            inputStream.close();
            assert outputStream != null;
            outputStream.close();
        }
    }
}
