package com.example.NetDisk.login;

import com.example.NetDisk.users.Users;
import com.example.NetDisk.utils.DruidUtils;
import com.example.NetDisk.utils.UploadUtils;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.dbutils.DbUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import java.beans.Beans;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

/**
 * @ClassName: ${NAME}
 * @Description: TODO
 * @author: LebronFans
 * @date: 2020/12/9  17:31
 */
@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        得到表单中的数据
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        if (username == null || password == null || "".equals(username) || "".equals(password)) {
            request.getRequestDispatcher("/failRegister").forward(request,response);
        }
        else {
            DataSource dataSource = DruidUtils.getDataSource();
            QueryRunner queryRunner = new QueryRunner(dataSource);
            try {
                Users users = queryRunner.query("select * from users where username = ?", new BeanHandler<>(Users.class), username);
                //            检测此用户名是否已经被注册,如果返回的结果不为空，说明不是第一次注册
                if (users != null) {
                    request.getRequestDispatcher("/failRegister").forward(request,response);
                }
                else {
                    queryRunner.update("INSERT INTO users values(null,?,?,NOW(),NULL)",username,password);
                }
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
            response.getWriter().println("注册成功，两秒钟后跳转至登录页面");
            response.setHeader("Refresh","2;url='/netdisk/login.html'");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
