package com.example.NetDisk.filelist;

import java.sql.Date;

/**
 * @ClassName: FileList
 * @Description: TODO
 * @author: LebronFans
 * @date: 2020/12/9  20:33
 */
public class FileList {
    private int id;

    private String username;

    private Date upload_time;

    private String filename;

    private String filepath;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Date getUpload_time() {
        return upload_time;
    }

    public void setUpload_time(Date upload_time) {
        this.upload_time = upload_time;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getFilepath() {
        return filepath;
    }

    public void setFilepath(String filepath) {
        this.filepath = filepath;
    }

    @Override
    public String toString() {
        return "FileList{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", upload_time=" + upload_time +
                ", filename='" + filename + '\'' +
                ", filepath='" + filepath + '\'' +
                '}';
    }
}
