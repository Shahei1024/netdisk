package com.example.NetDisk.users;

import java.sql.Date;

/**
 * @ClassName: Users
 * @Description: TODO
 * @author: LebronFans
 * @date: 2020/12/9  17:43
 */
public class Users {

    private int id;

    private String username;

    private String password;

    private Date register_time;

    private Date last_time;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getRegister_time() {
        return register_time;
    }

    public void setRegister_time(Date register_time) {
        this.register_time = register_time;
    }

    public Date getLast_time() {
        return last_time;
    }

    public void setLast_time(Date last_time) {
        this.last_time = last_time;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "Users{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", register_time=" + register_time +
                ", last_time=" + last_time +
                '}';
    }
}
