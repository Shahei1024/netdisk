package com.example.NetDisk.utils;

import com.alibaba.druid.pool.DruidDataSourceFactory;

import javax.sql.DataSource;
import java.io.InputStream;
import java.util.Properties;

/**
 * @ClassName: TestDruid
 * @Description: TODO
 * @author: LebronFans
 * @date: 2020/12/9  14:22
 */
public class DruidUtils {
    private static DataSource dataSource;
    static {
        Properties properties = new Properties();
//        通过类加载器加载配置文件，解析properties配置文件生成一个数据源
        InputStream inputStream = DruidUtils.class.getClassLoader().getResourceAsStream("druid.properties");
        try {
            properties.load(inputStream);
            dataSource = DruidDataSourceFactory.createDataSource(properties);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static DataSource getDataSource() {
//        返回一个数据源
        return dataSource;
    }
}
