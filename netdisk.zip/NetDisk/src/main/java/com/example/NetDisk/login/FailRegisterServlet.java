package com.example.NetDisk.login;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @ClassName: ${NAME}
 * @Description: TODO
 * @author: LebronFans
 * @date: 2020/12/9  19:48
 */
@WebServlet("/failRegister")
public class FailRegisterServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.getWriter().println("注册失败，请检查用户名或者密码是否输入正确或者该用户名已经被注册，两秒钟后跳转至注册界面");
        response.setHeader("Refresh","2;/netdisk/register.html");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
