package com.example.NetDisk.fileupload;

import com.example.NetDisk.filelist.FileList;
import com.example.NetDisk.users.Users;
import com.example.NetDisk.utils.DruidUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

/**
 * @ClassName: ${NAME}
 * @Description: TODO
 * @author: LebronFans
 * @date: 2020/12/9  21:01
 */
@WebServlet("/show")
public class ShowFileServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Users users = (Users) request.getSession().getAttribute("users");
        String username = users.getUsername();
        DataSource dataSource = DruidUtils.getDataSource();
        QueryRunner queryRunner = new QueryRunner(dataSource);
//        在数据库filelist表中找到符合相应用户名的信息并封装进FileList对象中
        try {
            List<FileList> query = queryRunner.query("select * from filelist where username = ?",
                    new BeanListHandler<>(FileList.class), username);
            response.getWriter().println(username + "，您上传的文件如下：");
            response.getWriter().println("<br>");
            for (FileList fileList : query) {
                response.getWriter().println("文件名： " + fileList.getFilename() + ","
                        + "上传时间： " + fileList.getUpload_time() + "|");
                response.getWriter().println("<a href='/netdisk/download?id=" + fileList.getId() + "'>Download</a>");
                response.getWriter().println("<br>");
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }
}
